from setuptools import setup

setup(
    name='author_rank',
    packages=['author_rank'],
    version='0.1.2',
    description='',
    author='Valentino Constantinou, Annie Didier',
    author_email='akdidier@jpl.caltech.edu',
    url='https://github.com/jburdo1/AuthorRank',
    download_url='https://github.com/jburdo/AuthorRank/dist/1.zip',
    keywords=['author_rank', 'PageRank', 'network', 'graph', 'edges', 'nodes', 'authorship', 'AuthorRank'],
    classifiers=[],
    license='MIT',
    install_requires=['networkx', 'python-utils', 'scipy']
)
